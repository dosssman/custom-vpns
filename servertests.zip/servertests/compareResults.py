from __future__ import print_function

import pickle
import numpy
import sys
import pandas as pd

savefilename0 = 'benchresults.2019-09-27_10_11_10.pkl'
savefilename1 = 'benchresults.2019-09-27_00_35_44-MOOV.pkl'
savefilename2 = 'benchresults.2019-09-27_00_50_49-ISOBOSS.pkl'

def load_res_from_pkl( filename):
    with open( filename, 'rb') as f:
        return pickle.load( f)

savefiles = [savefilename0, savefilename1, savefilename2]
ress = dict()

for savefilename in savefiles:
    ress[savefilename] = load_res_from_pkl(savefilename)

# print( ress)
### JP vs Moov
processed0 = dict()
processed1 = dict()

assert len( ress[savefilename0]) == len( ress[savefilename1])
assert len( ress[savefilename0]) == len( ress[savefilename2])

# print( ress[savefilename0])

for hostname in ress[savefilename0].keys():
    processed0[hostname] = { "Doss": ress[savefilename0][hostname],
        "DrazMoov": ress[savefilename1][hostname], "Sum": (ress[savefilename0][hostname] + ress[savefilename1][hostname])}
    processed1[hostname] = { "Doss": ress[savefilename0][hostname],
        "DrazISOBOSS": ress[savefilename2][hostname], "Sum": (ress[savefilename0][hostname] + ress[savefilename2][hostname])}

pd0 = pd.DataFrame.from_dict(processed0, orient='index', columns=[ 'DrazMoov', 'Doss', 'Sum'])
# pd0.sort_values( by=['Sum'])
pd0.to_excel( "DrazMoov.xlsx")

pd1 = pd.DataFrame.from_dict(processed1, orient='index', columns=[ 'DrazISOBOSS', 'Doss', 'Sum'])
# pd1.sort_values( by=['Sum'])
pd1.to_excel( "DrazISOBOSS.xlsx")

# Printing
print( "Doss & DrazMoov")
# print( pd0)
# for hostname in ress[savefilename0].keys():
#     print( '|%s|%.3f|%.3f|%.3f|' % (hostname, processed0[hostname]['Doss'], processed0[hostname]['DrazMoov'], processed0[hostname]['Sum']))

print("")
print("")
print( "Doss & DrazISOBOSS")
# print( pd1)
# for hostname in ress[savefilename0].keys():
#     print( '|%s|%.3f|%.3f|%.3f|' % (hostname, processed1[hostname]['Doss'], processed1[hostname]['DrazISOBOSS'], processed1[hostname]['Sum']))
