from __future__ import print_function

import os
import sys
import numpy
import pexpect
import platform

plat = platform.system()
scriptDir = sys.path[0]
hosts = os.path.join(scriptDir, 'hosts.txt')

class NetworkLatencyBenchmark(object):
    def __init__(self, ip, timeout=1200):
        object.__init__(self)

        self.ip = ip
        self.interval = 0.5

        ping_command = 'ping -i ' + str(self.interval) + ' ' + self.ip
        self.ping = pexpect.spawn(ping_command)

        self.ping.timeout = timeout
        self.ping.readline()  # init

        self.wifi_latency = []
        self.wifi_timeout = 0
        self.print_status = False

    def run_test(self, n_sample=100):
        for n in range(n_sample):
            p = self.ping.readline()

            try:
                ping_time = float(p[p.find('time=') + 5:p.find(' ms')])
                self.wifi_latency.append(ping_time)

            except Exception as e:
                self.wifi_timeout = self.wifi_timeout + 1
                self.wifi_latency.append( 99999)
                print( 'timeout')

        self.wifi_timeout = self.wifi_timeout / float(n_sample)
        self.wifi_latency = numpy.array(self.wifi_latency)

    def get_results(self):
        return numpy.mean(self.wifi_latency)

if __name__ == '__main__':
    with open( 'hosts.txt', 'r') as hostsfile:
        hosts = hostsfile.readlines()

    hosts = [ x.strip() for x in hosts]

    results = dict()

    hostcount = len( hosts)
    for k, host in enumerate( hosts):

        print( 'Benchmarking \'%s\' (%d/%d)' % (host, k, hostcount-1), end='')
        bench = NetworkLatencyBenchmark( host)
        bench.run_test( 10)
        results[host] = bench.get_results()
        print(' => Mean latency: %.4f' % (results[host]))

    from datetime import datetime
    strfiedDatetime = datetime.now().strftime("%Y-%m-%d_%H_%M_%S")
    savefilename = 'benchresults.%s.pkl' % (strfiedDatetime)
    savefilename = os.path.join(scriptDir, savefilename)

    print( 'Saving results to \'%s\'' % (savefilename))

    import pickle
    with open( savefilename, 'wb') as savef:
        pickle.dump( results, savef, pickle.HIGHEST_PROTOCOL)
